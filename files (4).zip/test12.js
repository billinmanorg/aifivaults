const fs=require('fs');const {JSDOM}=require('jsdom');
let pass=0,fail=0;const ok=(c,m)=>{c?pass++:(fail++,console.log('  FAIL '+m));};
const html=fs.readFileSync('v12.html','utf8');
const dom=new JSDOM(html,{runScripts:'dangerously',url:'https://aifivaults.netlify.app/'});
const w=dom.window,G=x=>w.eval(x),doc=w.document,$=s=>doc.querySelector(s),$$=s=>[...doc.querySelectorAll(s)];
const txt=()=>{const c=doc.body.cloneNode(true);c.querySelectorAll('script,style').forEach(n=>n.remove());return c.textContent;};

console.log('\n--- BRAND (§2) ---');
['AI5','AI Five','Audience Vaults','Working Materials','Prospect Portal','authorised','organisation','programme']
 .forEach(b=>ok(!txt().includes(b),'forbidden term: '+b));
ok(txt().includes('AiFi Vaults'),'product name present');

console.log('--- PUBLIC NAV (§6) ---');
const nav=$$('.site-nav a').map(a=>a.textContent);
ok(nav.length===5,'five nav items, got '+nav.length+' ['+nav.join(', ')+']');
ok(!nav.join(' ').match(/Calculator|Demos|What Is a Vault/),'gated tools removed from nav');
ok($('.header-cta a[href="#/sign-in"]'),'Sign In in main header');
ok($('.header-cta a[href="#/request-demo"]'),'Request a Demo is header CTA');

console.log('--- HOMEPAGE (§7,§8,§17,§18,§19) ---');
const t=txt();
ok(t.includes('before someone else owns the relationship'),'urgent hero headline');
ok(t.includes('Ask AiFi Vaults'),'chatbot present');
ok(t.indexOf('Ask AiFi Vaults')<t.indexOf('See what this means for you'),'chatbot directly after hero');
ok(t.includes('What happens if you wait'),'do-nothing comparison');
ok(t.includes('Why now')||t.includes('WHY NOW'),'urgency section');
ok(!t.includes('ANGL'),'no ANGL in public copy');
ok(!t.includes('Audience Acuity'),'no Audience Acuity publicly');
ok(!t.includes('Where the market is going'),'statistics hidden until verified');
ok(!t.includes('Five steps from community'),'five-step detail no longer on the homepage');
ok($$('h1').length===1,'exactly one h1');
ok($('svg[aria-label]')&&$('svg[aria-label]').getAttribute('aria-label').length>80,'hero diagram described for screen readers');
ok($$('[role=tab]').length===5,'five buyer paths as a tablist');

console.log('--- CHATBOT (§10) ---');
ok($('#ch-n')&&$('#ch-e'),'name and email before chat');
ok(!$('#ch-q'),'no chat input before capture');
$('#ch-n').value='Jordan Ellis';$('#ch-e').value='jordan@company.com';$('#ch-go').click();
ok($('#ch-q'),'chat opens after capture');
const c0=G('CRM').length;
ok(G('CRM').some(x=>x.email==='jordan@company.com'&&x.leadSource==='Homepage chatbot'),'CRM prospect created with lead source');
ok($$('#ch-sugg button').length===8,'eight suggested questions');
$('#ch-q').value='How can I make money with a Vault?';$('#ch-send').click();
let m=$$('.msg');
ok(m[m.length-1].textContent.includes('memberships'),'answers from approved knowledge');
ok(m[m.length-1].textContent.includes('Source:'),'answer cites its source');
$('#ch-q').value='Do you integrate with Salesforce Pardot?';$('#ch-send').click();
m=$$('.msg');
ok(m[m.length-1].textContent.includes('don\u2019t have a complete answer'),'unknown answer copy exact');
ok(m[m.length-1].classList.contains('flag'),'unknown answer flagged');
const lead=G('CRM').find(x=>x.email==='jordan@company.com');
ok(lead.status==='Follow-Up Needed','contact flagged for follow-up');
ok(lead.next.startsWith('Answer chatbot question'),'follow-up task recorded');
$('#ch-q').value='What is the pricing and cost?';$('#ch-send').click();
m=$$('.msg');
ok(!m[m.length-1].textContent.includes('Commercial terms'),'authenticated knowledge never leaks to public chat');
ok(G('CRM').length===c0,'repeat questions do not duplicate the contact');

console.log('--- GATING (§22,§23,§25) ---');
[['/what-is-a-vault','auth'],['/demos','auth'],['/portal/calculator','auth'],
 ['/tokenized-communities','auth'],['/data-protection','auth'],['/culture-and-legacy','auth'],
 ['/partners/audience-acuity','auth'],['/benefits','public'],['/vault-types','public'],
 ['/contact','public'],['/request-demo','public'],['/sign-in','public']]
 .forEach(([p,a])=>ok(G('ROUTES')[p]&&G('ROUTES')[p].access===a,p+' should be '+a));
ok(G('REDIRECTS')['/partners']==='/about','removed partner page redirects instead of 404ing');
ok(!txt().includes('Sign in as'),'no role selector at login');

console.log('--- REGRESSION: V1.1 SURVIVED ---');
ok(Object.keys(G('ROUTES')).length>25,'route table intact ('+Object.keys(G('ROUTES')).length+' routes)');
['/portal','/portal/calculator','/portal/scenarios','/admin/crm','/admin/cms','/admin/demos',
 '/admin/users','/admin/calculator','/admin/audit'].forEach(p=>ok(!!G('ROUTES')[p],p+' still exists'));
ok(G('CRM').length>5,'seeded CRM records intact');
ok(typeof G('money')==='function'&&G('money')(1500000)==='$1.50M','calculator formatting intact');
ok($('.site-footer'),'footer renders');
ok(!txt().includes('undefined'),'no undefined leaking into rendered copy');

console.log('\n'+pass+' passed, '+fail+' failed\n');
process.exit(fail?1:0);
